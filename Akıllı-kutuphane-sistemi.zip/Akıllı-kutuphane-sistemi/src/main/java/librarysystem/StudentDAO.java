package librarysystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    public void registerStudent(UniStudent st) {
        String query = "INSERT INTO tbl_students(full_name, major) VALUES(?, ?)";

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {

            ps.setString(1, st.getFullName());
            ps.setString(2, st.getStudyField());
            
            ps.executeUpdate();
            System.out.println(">> Öğrenci kaydı oluşturuldu: " + st.getFullName());

        } catch (SQLException ex) {
            System.err.println("Kayıt hatası: " + ex.getMessage());
        }
    }

    public List<UniStudent> fetchAll() {
        List<UniStudent> liste = new ArrayList<>();
        String query = "SELECT * FROM tbl_students";

        try (Connection c = MyDatabase.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(query)) {

            while (rs.next()) {
                UniStudent s = new UniStudent();
                s.setId(rs.getInt("id"));
                s.setFullName(rs.getString("full_name"));
                s.setStudyField(rs.getString("major"));
                
                liste.add(s);
            }
        } catch (SQLException ex) {
            System.err.println("Listeleme hatası: " + ex.getMessage());
        }
        return liste;
    }

    public UniStudent findById(int id) {
        String query = "SELECT * FROM tbl_students WHERE id = ?";
        UniStudent s = null;

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                s = new UniStudent(
                    rs.getInt("id"),
                    rs.getString("full_name"),
                    rs.getString("major")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Bulma hatası: " + ex.getMessage());
        }
        return s;
    }

    public void removeStudent(int id) {
        String query = "DELETE FROM tbl_students WHERE id = ?";

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println(">> Öğrenci kaydı silindi.");

        } catch (SQLException ex) {
            System.err.println("Silme hatası: " + ex.getMessage());
        }
    }

    public void updateStudent(UniStudent s) {
        String query = "UPDATE tbl_students SET full_name = ?, major = ? WHERE id = ?";

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {

            ps.setString(1, s.getFullName());
            ps.setString(2, s.getStudyField());
            ps.setInt(3, s.getId());

            ps.executeUpdate();
            System.out.println(">> Öğrenci güncellendi.");

        } catch (SQLException ex) {
            System.err.println("Güncelleme hatası: " + ex.getMessage());
        }
    }
}
