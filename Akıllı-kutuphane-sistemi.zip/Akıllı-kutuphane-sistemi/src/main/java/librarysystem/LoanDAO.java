package librarysystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LoanDAO {

    public void createLoan(LoanRecord lr) {
        String query = "INSERT INTO tbl_loans(book_id, student_id, issue_date, return_date) VALUES(?, ?, ?, ?)";

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {

            ps.setInt(1, lr.getRefBookId());
            ps.setInt(2, lr.getRefStudentId());
            ps.setString(3, lr.getIssueDate());
            ps.setString(4, lr.getReceiveDate()); 

            ps.executeUpdate();
            System.out.println(">> Ödünç verme işlemi kaydedildi.");

        } catch (SQLException ex) {
            System.err.println("İşlem hatası: " + ex.getMessage());
        }
    }

    public boolean isBookCurrentlyOut(int bookId) {
        String query = "SELECT count(*) FROM tbl_loans WHERE book_id = ? AND return_date IS NULL";
        
        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {
            
            ps.setInt(1, bookId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException ex) {
            System.err.println("Kontrol hatası: " + ex.getMessage());
        }
        return false;
    }

    public List<LoanRecord> fetchAll() {
        List<LoanRecord> records = new ArrayList<>();
        String query = "SELECT * FROM tbl_loans";

        try (Connection c = MyDatabase.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(query)) {

            while (rs.next()) {
                LoanRecord rec = new LoanRecord();
                rec.setId(rs.getInt("id"));
                rec.setRefBookId(rs.getInt("book_id"));
                rec.setRefStudentId(rs.getInt("student_id"));
                rec.setIssueDate(rs.getString("issue_date"));
                rec.setReceiveDate(rs.getString("return_date"));
                
                records.add(rec);
            }
        } catch (SQLException ex) {
            System.err.println("Listeleme hatası: " + ex.getMessage());
        }
        return records;
    }

    public void closeLoan(int bookId, String returnDate) {
        String query = "UPDATE tbl_loans SET return_date = ? WHERE book_id = ? AND return_date IS NULL";

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {

            ps.setString(1, returnDate);
            ps.setInt(2, bookId);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                System.out.println(">> İade işlemi başarılı.");
            } else {
                System.out.println(">> Bu kitap için aktif bir ödünç kaydı bulunamadı.");
            }

        } catch (SQLException ex) {
            System.err.println("İade hatası: " + ex.getMessage());
        }
    }
    
    public void removeRecord(int id) {
         String query = "DELETE FROM tbl_loans WHERE id = ?";
         try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {
             ps.setInt(1, id);
             ps.executeUpdate();
         } catch (SQLException ex) {
             System.err.println("Silme hatası: " + ex.getMessage());
         }
    }
    
    public void modifyRecord(LoanRecord lr) {
        // İhtiyaç halinde güncelleme
        String query = "UPDATE tbl_loans SET book_id=?, student_id=?, issue_date=?, return_date=? WHERE id=?";
        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {
            ps.setInt(1, lr.getRefBookId());
            ps.setInt(2, lr.getRefStudentId());
            ps.setString(3, lr.getIssueDate());
            ps.setString(4, lr.getReceiveDate());
            ps.setInt(5, lr.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Hata: " + ex.getMessage());
        }
    }
    
    public LoanRecord findById(int id) {
        String query = "SELECT * FROM tbl_loans WHERE id = ?";
        LoanRecord lr = null;
        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                lr = new LoanRecord(
                    rs.getInt("id"),
                    rs.getInt("book_id"),
                    rs.getInt("student_id"),
                    rs.getString("issue_date"),
                    rs.getString("return_date")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Hata: " + ex.getMessage());
        }
        return lr;
    }
}
