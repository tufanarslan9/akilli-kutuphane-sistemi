package librarysystem;

import java.util.List;
import java.util.Scanner;

public class RunApp {
    
    private static BookDAO bookManager = new BookDAO();
    private static StudentDAO studentManager = new StudentDAO();
    private static LoanDAO loanManager = new LoanDAO();
    
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        MyDatabase.initialize();
        
        System.out.println("#############################################");
        System.out.println("#      KÜTÜPHANE YÖNETİM SİSTEMİ v2.0       #");
        System.out.println("#############################################");

        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Seçiminiz: ");

            int selection;
            try {
                selection = Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Lütfen rakam giriniz.");
                continue;
            }

            switch (selection) {
                case 1:
                    newBook();
                    break;
                case 2:
                    showBooks();
                    break;
                case 3:
                    newStudent();
                    break;
                case 4:
                    showStudents();
                    break;
                case 5:
                    borrowBook();
                    break;
                case 6:
                    showHistory();
                    break;
                case 7:
                    returnBook();
                    break;
                case 0:
                    System.out.println("Sistemden çıkılıyor...");
                    running = false;
                    break;
                default:
                    System.out.println("Geçersiz işlem numarası!");
            }
        }
    }
    
    private static void printMenu() {
        System.out.println("\n--- ANA MENÜ ---");
        System.out.println("1 - Yeni Kitap Tanımla");
        System.out.println("2 - Kayıtlı Kitapları Göster");
        System.out.println("3 - Yeni Üye (Öğrenci) Ekle");
        System.out.println("4 - Üye Listesi");
        System.out.println("5 - Ödünç Ver");
        System.out.println("6 - Hareket Dökümü (Ödünç Listesi)");
        System.out.println("7 - Kitap İade Al");
        System.out.println("0 - Kapat");
    }

    private static void newBook() {
        System.out.print("Eser Adı: ");
        String title = input.nextLine();
        
        System.out.print("Yazarı: ");
        String author = input.nextLine();
        
        System.out.print("Yayın Yılı: ");
        int year = 0;
        try {
            year = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Hatalı yıl formatı.");
            return;
        }

        LibraryBook b = new LibraryBook(title, author, year);
        bookManager.insertBook(b);
    }

    private static void showBooks() {
        List<LibraryBook> list = bookManager.fetchAll();
        if (list.isEmpty()) {
            System.out.println("Kütüphanede kayıtlı kitap yok.");
        } else {
            System.out.println("=== KİTAPLAR ===");
            for (LibraryBook b : list) {
                System.out.println(b);
            }
        }
    }

    private static void newStudent() {
        System.out.print("Öğrenci Ad Soyad: ");
        String name = input.nextLine();
        
        System.out.print("Bölümü: ");
        String dept = input.nextLine();

        UniStudent s = new UniStudent(name, dept);
        studentManager.registerStudent(s);
    }

    private static void showStudents() {
        List<UniStudent> list = studentManager.fetchAll();
        if (list.isEmpty()) {
            System.out.println("Kayıtlı öğrenci bulunamadı.");
        } else {
            System.out.println("=== ÖĞRENCİLER ===");
            for (UniStudent s : list) {
                System.out.println(s);
            }
        }
    }

    private static void borrowBook() {
        showBooks();
        System.out.print("Verilecek Kitap ID: ");
        int bId = 0;
        try {
            bId = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Hata.");
            return;
        }

        if (loanManager.isBookCurrentlyOut(bId)) {
            System.out.println("UYARI: Bu kitap şu an müsait değil (Başkasında).");
            return;
        }
        
        LibraryBook book = bookManager.findById(bId);
        if (book == null) {
            System.out.println("Kitap bulunamadı.");
            return;
        }

        showStudents();
        System.out.print("Alacak Öğrenci ID: ");
        int sId = 0;
        try {
            sId = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Hata.");
            return;
        }
        
        UniStudent student = studentManager.findById(sId);
        if (student == null) {
            System.out.println("Öğrenci bulunamadı.");
            return;
        }

        System.out.print("Tarih (Yıl-Ay-Gün): ");
        String date = input.nextLine();

        LoanRecord rec = new LoanRecord(bId, sId, date);
        loanManager.createLoan(rec);
    }

    private static void showHistory() {
        List<LoanRecord> list = loanManager.fetchAll();
        if (list.isEmpty()) {
            System.out.println("Henüz işlem kaydı yok.");
        } else {
            System.out.println("=== HAREKET GEÇMİŞİ ===");
            for (LoanRecord r : list) {
                LibraryBook b = bookManager.findById(r.getRefBookId());
                UniStudent s = studentManager.findById(r.getRefStudentId());
                
                String bName = (b != null) ? b.getBookTitle() : "Silinmiş Kitap";
                String sName = (s != null) ? s.getFullName() : "Silinmiş Üye";
                
                System.out.println(r + " => " + bName + " <-> " + sName);
            }
        }
    }

    private static void returnBook() {
        System.out.print("Teslim Edilen Kitap ID: ");
        int bId = 0;
        try {
            bId = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Hata.");
            return;
        }

        System.out.print("İade Tarihi: ");
        String date = input.nextLine();

        loanManager.closeLoan(bId, date);
    }
}
