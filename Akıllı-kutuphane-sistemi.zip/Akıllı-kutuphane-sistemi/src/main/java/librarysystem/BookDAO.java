package librarysystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    public void insertBook(LibraryBook bk) {
        String query = "INSERT INTO tbl_books(title, author, pub_year) VALUES(?, ?, ?)";

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {
            
            ps.setString(1, bk.getBookTitle());
            ps.setString(2, bk.getBookAuthor());
            ps.setInt(3, bk.getPubYear());
            
            ps.executeUpdate();
            System.out.println(">> Yeni kitap sisteme eklendi: " + bk.getBookTitle());
            
        } catch (SQLException ex) {
            System.err.println("Ekleme hatası: " + ex.getMessage());
        }
    }

    public List<LibraryBook> fetchAll() {
        List<LibraryBook> liste = new ArrayList<>();
        String query = "SELECT * FROM tbl_books";

        try (Connection c = MyDatabase.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(query)) {

            while (rs.next()) {
                LibraryBook item = new LibraryBook();
                item.setId(rs.getInt("id"));
                item.setBookTitle(rs.getString("title"));
                item.setBookAuthor(rs.getString("author"));
                item.setPubYear(rs.getInt("pub_year"));
                
                liste.add(item);
            }
        } catch (SQLException ex) {
            System.err.println("Listeleme hatası: " + ex.getMessage());
        }
        return liste;
    }

    public LibraryBook findById(int id) {
        String query = "SELECT * FROM tbl_books WHERE id = ?";
        LibraryBook found = null;

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {
             
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                found = new LibraryBook(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getInt("pub_year")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Arama hatası: " + ex.getMessage());
        }
        return found;
    }
    
    public void removeBook(int id) {
        String query = "DELETE FROM tbl_books WHERE id = ?";

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println(">> Kitap silindi.");

        } catch (SQLException ex) {
            System.err.println("Silme hatası: " + ex.getMessage());
        }
    }
    
    public void modifyBook(LibraryBook bk) {
        String query = "UPDATE tbl_books SET title = ?, author = ?, pub_year = ? WHERE id = ?";

        try (Connection c = MyDatabase.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {

            ps.setString(1, bk.getBookTitle());
            ps.setString(2, bk.getBookAuthor());
            ps.setInt(3, bk.getPubYear());
            ps.setInt(4, bk.getId());
            
            ps.executeUpdate();
            System.out.println(">> Kitap bilgileri güncellendi.");

        } catch (SQLException ex) {
            System.err.println("Güncelleme hatası: " + ex.getMessage());
        }
    }
}
