package librarysystem;

public class UniStudent {
    private int id;
    private String fullName; // name yerine
    private String studyField; // department yerine

    public UniStudent() {
    }

    public UniStudent(int id, String fullName, String studyField) {
        this.id = id;
        this.fullName = fullName;
        this.studyField = studyField;
    }

    public UniStudent(String fullName, String studyField) {
        this.fullName = fullName;
        this.studyField = studyField;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getStudyField() {
        return studyField;
    }

    public void setStudyField(String studyField) {
        this.studyField = studyField;
    }

    @Override
    public String toString() {
        return id + " # " + fullName + " [" + studyField + "]";
    }
}
