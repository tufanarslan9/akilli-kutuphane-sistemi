package librarysystem;

public class LoanRecord {
    private int id;
    private int refBookId;    // bookId yerine
    private int refStudentId; // studentId yerine
    private String issueDate; // dateBorrowed yerine
    private String receiveDate; // dateReturned yerine

    public LoanRecord() {
    }

    public LoanRecord(int id, int refBookId, int refStudentId, String issueDate, String receiveDate) {
        this.id = id;
        this.refBookId = refBookId;
        this.refStudentId = refStudentId;
        this.issueDate = issueDate;
        this.receiveDate = receiveDate;
    }

    public LoanRecord(int refBookId, int refStudentId, String issueDate) {
        this.refBookId = refBookId;
        this.refStudentId = refStudentId;
        this.issueDate = issueDate;
        this.receiveDate = null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRefBookId() {
        return refBookId;
    }

    public void setRefBookId(int refBookId) {
        this.refBookId = refBookId;
    }

    public int getRefStudentId() {
        return refStudentId;
    }

    public void setRefStudentId(int refStudentId) {
        this.refStudentId = refStudentId;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getReceiveDate() {
        return receiveDate;
    }

    public void setReceiveDate(String receiveDate) {
        this.receiveDate = receiveDate;
    }
    
    public String getStatus() {
        return (receiveDate == null) ? "Devam Ediyor" : "Tamamlandı";
    }

    @Override
    public String toString() {
        return "İşlem No: " + id + ", KitapID: " + refBookId + ", ÜyeID: " + refStudentId + 
               ", Veriliş: " + issueDate + ", Durum: " + getStatus();
    }
}
