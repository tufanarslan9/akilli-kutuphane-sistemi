package librarysystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MyDatabase {

    // Veritabanı dosya ismi değiştirildi
    private static final String CONNECTION_STRING = "jdbc:sqlite:sistem.db";

    public static Connection getConnection() {
        Connection baglanti = null;
        try {
            baglanti = DriverManager.getConnection(CONNECTION_STRING);
        } catch (SQLException ex) {
            System.err.println("Bağlantı hatası: " + ex.getMessage());
        }
        return baglanti;
    }

    public static void initialize() {
        // Tablo isimleri tbl_ öneki ile değiştirildi
        String createBookTable = "CREATE TABLE IF NOT EXISTS tbl_books (\n"
                + " id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " title TEXT NOT NULL,\n"
                + " author TEXT NOT NULL,\n"
                + " pub_year INTEGER\n" // year -> pub_year
                + ");";

        String createStudentTable = "CREATE TABLE IF NOT EXISTS tbl_students (\n"
                + " id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " full_name TEXT NOT NULL,\n" // name -> full_name
                + " major TEXT NOT NULL\n" // department -> major
                + ");";

        String createLoanTable = "CREATE TABLE IF NOT EXISTS tbl_loans (\n"
                + " id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " book_id INTEGER,\n"
                + " student_id INTEGER,\n"
                + " issue_date TEXT,\n" // dateBorrowed -> issue_date
                + " return_date TEXT,\n" // dateReturned -> return_date
                + " FOREIGN KEY (book_id) REFERENCES tbl_books (id),\n"
                + " FOREIGN KEY (student_id) REFERENCES tbl_students (id)\n"
                + ");";

        try (Connection conn = getConnection();
             Statement st = conn.createStatement()) {
            
            st.execute(createBookTable);
            st.execute(createStudentTable);
            st.execute(createLoanTable);
            
        } catch (SQLException ex) {
            System.err.println("Tablo oluşturma hatası: " + ex.getMessage());
        }
    }
}
