package librarysystem;

public class LibraryBook {
    private int id;
    private String bookTitle;  // title yerine
    private String bookAuthor; // author yerine
    private int pubYear;       // year yerine

    public LibraryBook() {
    }

    public LibraryBook(int id, String bookTitle, String bookAuthor, int pubYear) {
        this.id = id;
        this.bookTitle = bookTitle;
        this.bookAuthor = bookAuthor;
        this.pubYear = pubYear;
    }
    
    public LibraryBook(String bookTitle, String bookAuthor, int pubYear) {
        this.bookTitle = bookTitle;
        this.bookAuthor = bookAuthor;
        this.pubYear = pubYear;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public int getPubYear() {
        return pubYear;
    }

    public void setPubYear(int pubYear) {
        this.pubYear = pubYear;
    }

    @Override
    public String toString() {
        return id + " - " + bookTitle + " (" + bookAuthor + ", " + pubYear + ")";
    }
}
